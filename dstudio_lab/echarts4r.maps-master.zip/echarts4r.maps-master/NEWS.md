# echarts4r.maps 0.0.2

- Added cities data `data(cities)`

# echarts4r.maps 0.0.1

* Added `e_maps` to combine maps.
